package com.example.a2020_04_24project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.icu.text.CaseMap;
import android.icu.text.IDNA;
import android.os.Bundle;
import android.view.View;
import android.view.ViewDebug;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button start, info, help;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        start=(Button)findViewById(R.id.start);
        info=(Button)findViewById(R.id.info);
        help=(Button)findViewById(R.id.help);
        setContentView(R.layout.activity_main);
        Intent intent=new Intent(this, splash.class);
        startActivity(intent);
    }
    public void click(View v){
        Intent Start= new Intent(getApplicationContext(),start.class);
        Intent Info = new Intent(getApplicationContext(),info.class);
        Intent Help= new Intent(getApplicationContext(), help.class);
        switch (v.getId()){
            case R.id.start:
                startActivity(Start);
                break;
            case R.id.info:
                startActivity(Info);
                break;
            case R.id.help:
                startActivity(Help);
                break;

        }


    }

}
